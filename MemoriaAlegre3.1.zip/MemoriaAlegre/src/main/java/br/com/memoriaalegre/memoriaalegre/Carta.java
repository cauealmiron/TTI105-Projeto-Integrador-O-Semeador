package br.com.memoriaalegre.memoriaalegre;

//import control.FlipCardActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import javax.swing.JToggleButton;

public class Carta extends TelaFase1 {
    
    private String pathName;
    private ArrayList<String> cartasFrutas;

    // Adicionando referências para os botões
    private JToggleButton CartaToggleButton1;
    private JToggleButton CartaToggleButton2;
    private JToggleButton CartaToggleButton3;
    private JToggleButton CartaToggleButton4;
    private JToggleButton CartaToggleButton5;
    private JToggleButton CartaToggleButton6;

    public Carta(JToggleButton btn1, JToggleButton btn2, JToggleButton btn3, 
                 JToggleButton btn4, JToggleButton btn5, JToggleButton btn6) {
        // Inicializa os botões
        this.CartaToggleButton1 = btn1;
        this.CartaToggleButton2 = btn2;
        this.CartaToggleButton3 = btn3;
        this.CartaToggleButton4 = btn4;
        this.CartaToggleButton5 = btn5;
        this.CartaToggleButton6 = btn6;
        
        // Inicializa a lista de cartas
        this.cartasFrutas = new ArrayList<>();
        cartasFrutas.add("maca");
        cartasFrutas.add("maca");
        cartasFrutas.add("banana");
        cartasFrutas.add("banana");
        cartasFrutas.add("uva");
        cartasFrutas.add("uva");

        // Embaralha as cartas ao inicializar
        Collections.shuffle(cartasFrutas);
        
        CartaToggleButton1.addActionListener(new FlipCardActionListener(CartaToggleButton1, 0));
        CartaToggleButton2.addActionListener(new FlipCardActionListener(CartaToggleButton2, 1));
        CartaToggleButton3.addActionListener(new FlipCardActionListener(CartaToggleButton3, 2));
        CartaToggleButton4.addActionListener(new FlipCardActionListener(CartaToggleButton4, 3));
        CartaToggleButton5.addActionListener(new FlipCardActionListener(CartaToggleButton5, 4));
        CartaToggleButton6.addActionListener(new FlipCardActionListener(CartaToggleButton6, 5));
    }
    
        private class FlipCardActionListener implements ActionListener {
        private JToggleButton button;
        private int cardIndex;

        public FlipCardActionListener(JToggleButton button, int cardIndex) {
        this.button = button;
        this.cardIndex = cardIndex;
    }
        @Override
        public void actionPerformed(ActionEvent e) {
        if (button.isSelected()) {
            String pathName = "images/" + cartasFrutas.get(cardIndex) + ".png";
            button.setIcon(new javax.swing.ImageIcon(getClass().getResource(pathName)));
        } else {
            button.setIcon(new javax.swing.ImageIcon(getClass().getResource("images/cerebro.png")));
        }
    }
}
 

    public void setImage() {
        if (cartasFrutas != null && cartasFrutas.size() >= 6) {
            pathName = "images/" + cartasFrutas.get(0) + ".png";
            CartaToggleButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource(pathName)));
            pathName = "images/" + cartasFrutas.get(1) + ".png";
            CartaToggleButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource(pathName)));
            pathName = "images/" + cartasFrutas.get(2) + ".png";
            CartaToggleButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource(pathName)));
            pathName = "images/" + cartasFrutas.get(3) + ".png";
            CartaToggleButton4.setIcon(new javax.swing.ImageIcon(getClass().getResource(pathName)));
            pathName = "images/" + cartasFrutas.get(4) + ".png";
            CartaToggleButton5.setIcon(new javax.swing.ImageIcon(getClass().getResource(pathName)));
            pathName = "images/" + cartasFrutas.get(5) + ".png";
            CartaToggleButton6.setIcon(new javax.swing.ImageIcon(getClass().getResource(pathName)));
        }
    }

    public void setBackOfCardImage() {
        CartaToggleButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("images/cerebro.png")));
    }

    // Método para sortear cartas, caso queira sortear novamente
    public void sortearNovasCartas() {
        Collections.shuffle(cartasFrutas);
    }
    
    private int countSelectedCards() {
    int count = 0;
    if (CartaToggleButton1.isSelected()) count++;
    if (CartaToggleButton2.isSelected()) count++;
    if (CartaToggleButton3.isSelected()) count++;
    if (CartaToggleButton4.isSelected()) count++;
    if (CartaToggleButton5.isSelected()) count++;
    if (CartaToggleButton6.isSelected()) count++;
    return count;
}
    public void actionPerformed(ActionEvent e) {
        if (button.isSelected()) {
            if (countSelectedCards() > 2) {
                // Desmarcar a carta se mais de duas cartas estiverem selecionadas
                button.setSelected(false);
            } else {
                pathName = "images/" + cartasFrutas.get(cardIndex) + ".png";
                button.setIcon(new javax.swing.ImageIcon(getClass().getResource(pathName)));
            }
        } else {
            todasCartasFrutas.setIcon(new javax.swing.ImageIcon(getClass().getResource("images/cerebro.png")));
        }
    }
}
    






