package br.com.memoriaalegre.memoriaalegre;

public class TelaInicial extends javax.swing.JFrame {

    public TelaInicial() {
        initComponents();
        setLocationRelativeTo(null);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        NomeAdministradorTextField = new javax.swing.JTextField();
        PasswordField = new javax.swing.JPasswordField();
        EntrarButton = new javax.swing.JButton();
        SairButton = new javax.swing.JButton();
        GardenLabel = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(1200, 800));
        getContentPane().setLayout(null);

        jLabel1.setFont(new java.awt.Font("Trebuchet MS", 1, 24)); // NOI18N
        jLabel1.setText("Senha");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(610, 430, 70, 30);

        jLabel2.setFont(new java.awt.Font("Trebuchet MS", 1, 24)); // NOI18N
        jLabel2.setText("Nome Administrador");
        getContentPane().add(jLabel2);
        jLabel2.setBounds(530, 280, 240, 29);

        NomeAdministradorTextField.setFont(new java.awt.Font("Trebuchet MS", 1, 18)); // NOI18N
        getContentPane().add(NomeAdministradorTextField);
        NomeAdministradorTextField.setBounds(480, 340, 340, 40);

        PasswordField.setFont(new java.awt.Font("Trebuchet MS", 1, 18)); // NOI18N
        PasswordField.setText("jPasswordField1");
        getContentPane().add(PasswordField);
        PasswordField.setBounds(480, 480, 340, 40);

        EntrarButton.setFont(new java.awt.Font("Trebuchet MS", 1, 18)); // NOI18N
        EntrarButton.setText("Entrar");
        EntrarButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EntrarButtonActionPerformed(evt);
            }
        });
        getContentPane().add(EntrarButton);
        EntrarButton.setBounds(710, 590, 120, 50);

        SairButton.setFont(new java.awt.Font("Trebuchet MS", 1, 18)); // NOI18N
        SairButton.setText("Sair");
        SairButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SairButtonActionPerformed(evt);
            }
        });
        getContentPane().add(SairButton);
        SairButton.setBounds(460, 590, 120, 50);

        GardenLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/telaAdm_1.jpg"))); // NOI18N
        getContentPane().add(GardenLabel);
        GardenLabel.setBounds(0, 0, 1270, 800);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void EntrarButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EntrarButtonActionPerformed
        TelaConfigurações tc = new TelaConfigurações();
        tc.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_EntrarButtonActionPerformed

    private void SairButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SairButtonActionPerformed
        this.dispose();
    }//GEN-LAST:event_SairButtonActionPerformed

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TelaInicial().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton EntrarButton;
    private javax.swing.JLabel GardenLabel;
    private javax.swing.JTextField NomeAdministradorTextField;
    private javax.swing.JPasswordField PasswordField;
    private javax.swing.JButton SairButton;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    // End of variables declaration//GEN-END:variables
}
