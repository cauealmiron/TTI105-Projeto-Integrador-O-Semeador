package br.com.memoriaalegre.memoriaalegre;

/**
 *
 * @author Gustavo
 */
public class FimDeJogoFrutas extends javax.swing.JFrame {

    public FimDeJogoFrutas() {
        initComponents();
        setLocationRelativeTo(null);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        SairButtonFimJogo = new javax.swing.JButton();
        ConsultarPlacarButtonFim = new javax.swing.JButton();
        RestartButton = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        TabelaLabel = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMaximizedBounds(new java.awt.Rectangle(0, 0, 1280, 800));
        setMinimumSize(new java.awt.Dimension(1280, 800));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        SairButtonFimJogo.setFont(new java.awt.Font("Trebuchet MS", 1, 18)); // NOI18N
        SairButtonFimJogo.setText("Sair");
        SairButtonFimJogo.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED, null, java.awt.Color.lightGray, null, null));
        SairButtonFimJogo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SairButtonFimJogoActionPerformed(evt);
            }
        });
        getContentPane().add(SairButtonFimJogo, new org.netbeans.lib.awtextra.AbsoluteConstraints(750, 450, 180, 30));

        ConsultarPlacarButtonFim.setFont(new java.awt.Font("Trebuchet MS", 1, 18)); // NOI18N
        ConsultarPlacarButtonFim.setText("Consultar Placar ");
        ConsultarPlacarButtonFim.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED, null, java.awt.Color.lightGray, null, null));
        ConsultarPlacarButtonFim.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ConsultarPlacarButtonFimActionPerformed(evt);
            }
        });
        getContentPane().add(ConsultarPlacarButtonFim, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 450, 180, 30));

        RestartButton.setFont(new java.awt.Font("Trebuchet MS", 1, 18)); // NOI18N
        RestartButton.setText("Recomeçar");
        RestartButton.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED, null, java.awt.Color.lightGray, null, null));
        RestartButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RestartButtonActionPerformed(evt);
            }
        });
        getContentPane().add(RestartButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 450, 180, 30));

        jLabel1.setFont(new java.awt.Font("Trebuchet MS", 0, 80)); // NOI18N
        jLabel1.setText("Fim de Jogo!");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 320, 470, 90));

        TabelaLabel.setBackground(new java.awt.Color(255, 255, 255));
        TabelaLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/fimTela_1.jpg"))); // NOI18N
        getContentPane().add(TabelaLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, -140, 1920, 1080));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void ConsultarPlacarButtonFimActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ConsultarPlacarButtonFimActionPerformed
       TelaTabelaAluno tt = new TelaTabelaAluno();
       tt.setVisible(true);
    }//GEN-LAST:event_ConsultarPlacarButtonFimActionPerformed

    private void RestartButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RestartButtonActionPerformed
        TelaFase1 tf = new TelaFase1();
        tf.setVisible(true);
    }//GEN-LAST:event_RestartButtonActionPerformed

    private void SairButtonFimJogoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SairButtonFimJogoActionPerformed
    TelaInicial ti = new TelaInicial();
    ti.setVisible(true);
    }//GEN-LAST:event_SairButtonFimJogoActionPerformed

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FimDeJogoFrutas().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton ConsultarPlacarButtonFim;
    private javax.swing.JButton RestartButton;
    private javax.swing.JButton SairButtonFimJogo;
    private javax.swing.JLabel TabelaLabel;
    private javax.swing.JLabel jLabel1;
    // End of variables declaration//GEN-END:variables
}
