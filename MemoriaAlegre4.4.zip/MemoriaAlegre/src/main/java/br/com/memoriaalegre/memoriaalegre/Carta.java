package br.com.memoriaalegre.memoriaalegre;

import java.awt.event.ActionListener;
import java.util.Timer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.TimerTask;

import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.JToggleButton;
import javax.swing.SwingUtilities;

public class Carta extends TelaFase1 {
    
    int contador = 0;
    int pontos = 0;
    String pontosString = String.valueOf(pontos);
    
    // Criação das Listas de cartas JToggleButton
    private ArrayList<String> cartasNumeros;
    private ArrayList<String> cartasFiguras;
    private ArrayList<String> cartasFrutas;
    private ArrayList<JToggleButton> botoes;
    private ArrayList<JToggleButton> Acertobotoes;
    private ArrayList<JToggleButton> contadorCartasfrutas;
    private ArrayList<JToggleButton> contadorCartasFigura;
    private ArrayList<JToggleButton> contadorCartasNumeros;
    
    private Map<String, JToggleButton> todasCartasNumeros = new HashMap<>();
    private Map<String, JToggleButton> todasCartasFiguras = new HashMap<>();
    private Map<String, JToggleButton> todasCartasFrutas = new HashMap<>();
    private Carta carta;
    
    public Carta() {
        
        
        this.contadorCartasNumeros = new ArrayList<>();
        this.contadorCartasFigura = new ArrayList<>();
        this.contadorCartasfrutas = new ArrayList<>();
        this.botoes = new ArrayList<>();
        this.Acertobotoes = new ArrayList<>();
        
        // Inicializa a lista de cartas
        this.cartasNumeros = new ArrayList<>();
        cartasNumeros.add("um");
        cartasNumeros.add("um");
        cartasNumeros.add("dois");
        cartasNumeros.add("dois");
        cartasNumeros.add("tres");
        cartasNumeros.add("tres");
        this.cartasFiguras = new ArrayList<>();
        cartasFiguras.add("piramide");
        cartasFiguras.add("piramide");
        cartasFiguras.add("cubo");
        cartasFiguras.add("cubo");
        cartasFiguras.add("circulo");
        cartasFiguras.add("circulo");
        this.cartasFrutas = new ArrayList<>();
        cartasFrutas.add("maca");
        cartasFrutas.add("maca");
        cartasFrutas.add("banana");
        cartasFrutas.add("banana");
        cartasFrutas.add("uva");
        cartasFrutas.add("uva");

        // Embaralha as cartas ao inicializar
        Collections.shuffle(cartasFrutas);
        Collections.shuffle(cartasFiguras);
        Collections.shuffle(cartasNumeros);
        
    }   
    public void validarParBotoes() {
        if (contador > 1){
            ImageIcon botao1 = (ImageIcon) botoes.get(0).getIcon();
            ImageIcon botao2 = (ImageIcon) botoes.get(1).getIcon();
            String btn1String = String.valueOf(botao1);
            String btn2String = String.valueOf(botao2);
            System.out.println(btn1String);
            System.out.println(btn2String);
            if(btn1String.equals(btn2String)){
                pontos += 100;
                Acertobotoes.add(botoes.get(0));
                Acertobotoes.add(botoes.get(1));
                contadorCartasfrutas.add(botoes.get(0));
                contadorCartasfrutas.add(botoes.get(1));
                botoes.clear();
                JOptionPane.showMessageDialog(null, "Par Válido");
                CartaToggleButton1.setEnabled(true);
                CartaToggleButton2.setEnabled(true);
                CartaToggleButton3.setEnabled(true);
                CartaToggleButton4.setEnabled(true);
                CartaToggleButton5.setEnabled(true);
                CartaToggleButton6.setEnabled(true);
                System.out.println(pontosString);                            
                contador = 0;
                pontosString = String.valueOf(pontos);
            }
            else{ 
                try {            
            Thread.sleep(000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
                JOptionPane.showMessageDialog(null, "Par inválido");
                virarCartas();
                botoes.clear();
                CartaToggleButton1.setEnabled(true);
                CartaToggleButton2.setEnabled(true);
                CartaToggleButton3.setEnabled(true);
                CartaToggleButton4.setEnabled(true);
                CartaToggleButton5.setEnabled(true);
                CartaToggleButton6.setEnabled(true);
                contador = 0;
            }
        }
        else{
        }

    }
    
    public void virarCartas(){
        botoes.get(0).setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/cerebro.png")));
        botoes.get(1).setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/cerebro.png")));
    }
    
    public void limitadorBotoes(){
        if (contador > 1){
           CartaToggleButton1.setEnabled(false);
           CartaToggleButton2.setEnabled(false);
           CartaToggleButton3.setEnabled(false);
           CartaToggleButton4.setEnabled(false);
           CartaToggleButton5.setEnabled(false);
           CartaToggleButton6.setEnabled(false);
        }
    }
    
    public void reiniciarCartas(){
        if (contadorCartasfrutas.size()  == 6){
              
              contadorCartasfrutas.clear();
              
              Collections.shuffle(cartasFrutas);
              
              CartaToggleButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/cerebro.png")));
              CartaToggleButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/cerebro.png")));
              CartaToggleButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/cerebro.png")));
              CartaToggleButton4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/cerebro.png")));
              CartaToggleButton5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/cerebro.png")));
              CartaToggleButton6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/cerebro.png")));
        }
    }
}







    






