package br.com.memoriaalegre.memoriaalegre;

/**
 *
 * @author Gustavo
 */
public class TelaTabelaProfessor extends javax.swing.JFrame {

    public TelaTabelaProfessor() {
        initComponents();
        setLocationRelativeTo(null);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        VoltarTabelaButton = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        TabelaPontuação = new javax.swing.JTable();
        TextoTabela = new javax.swing.JLabel();
        TabelaLabel = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMaximizedBounds(new java.awt.Rectangle(0, 0, 1280, 800));
        setMaximumSize(new java.awt.Dimension(1280, 800));
        setMinimumSize(new java.awt.Dimension(1280, 800));
        setPreferredSize(new java.awt.Dimension(1280, 800));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        VoltarTabelaButton.setFont(new java.awt.Font("Trebuchet MS", 1, 20)); // NOI18N
        VoltarTabelaButton.setText("Voltar");
        VoltarTabelaButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                VoltarTabelaButtonActionPerformed(evt);
            }
        });
        getContentPane().add(VoltarTabelaButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(870, 960, 170, 40));

        TabelaPontuação.setBackground(new java.awt.Color(204, 204, 204));
        TabelaPontuação.setFont(new java.awt.Font("Trebuchet MS", 1, 24)); // NOI18N
        TabelaPontuação.setForeground(new java.awt.Color(255, 255, 255));
        TabelaPontuação.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Nome", "Pontuação", "Tempo", "Turma"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.Integer.class, java.lang.Double.class, java.lang.Integer.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        TabelaPontuação.setToolTipText("");
        TabelaPontuação.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        TabelaPontuação.setGridColor(new java.awt.Color(255, 255, 255));
        TabelaPontuação.setName(""); // NOI18N
        TabelaPontuação.setRequestFocusEnabled(false);
        TabelaPontuação.setRowHeight(70);
        TabelaPontuação.setShowGrid(false);
        TabelaPontuação.setShowHorizontalLines(true);
        jScrollPane1.setViewportView(TabelaPontuação);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 220, 970, 420));

        TextoTabela.setFont(new java.awt.Font("Trebuchet MS", 1, 60)); // NOI18N
        TextoTabela.setText("Tabela de Pontuações");
        getContentPane().add(TextoTabela, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 140, 640, 60));

        TabelaLabel.setBackground(new java.awt.Color(255, 255, 255));
        TabelaLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/telattabela_1.jpg"))); // NOI18N
        getContentPane().add(TabelaLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, -140, 1920, 1080));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void VoltarTabelaButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_VoltarTabelaButtonActionPerformed
        this.dispose();
        TelaConfigurações tc = new TelaConfigurações();
        tc.setVisible(true);
        
    }//GEN-LAST:event_VoltarTabelaButtonActionPerformed

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TelaTabelaProfessor().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel TabelaLabel;
    private javax.swing.JTable TabelaPontuação;
    private javax.swing.JLabel TextoTabela;
    private javax.swing.JButton VoltarTabelaButton;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
