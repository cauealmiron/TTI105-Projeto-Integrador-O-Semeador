

package br.com.memoriaalegre.memoriaalegre;
import control.Controlador;
public class TelaNomeAluno extends TelaFase1 {;

       public TelaNomeAluno() {
        initComponents();       
        nomeAluno.setText("Bem vindo, " + Controlador.getNome()+ "!" );
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        nomeAluno = new javax.swing.JLabel();
        sairButtonAluno = new javax.swing.JButton();
        iniciarPartidaAlunoButton = new javax.swing.JButton();
        GardenBackLabel = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(1280, 800));
        setResizable(false);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        nomeAluno.setFont(new java.awt.Font("Trebuchet MS", 1, 28)); // NOI18N
        nomeAluno.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        nomeAluno.setToolTipText("");
        getContentPane().add(nomeAluno, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 130, 490, 70));

        sairButtonAluno.setFont(new java.awt.Font("Trebuchet MS", 1, 36)); // NOI18N
        sairButtonAluno.setText("Sair");
        sairButtonAluno.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sairButtonAlunoActionPerformed(evt);
            }
        });
        getContentPane().add(sairButtonAluno, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 430, 310, 60));

        iniciarPartidaAlunoButton.setFont(new java.awt.Font("Trebuchet MS", 1, 36)); // NOI18N
        iniciarPartidaAlunoButton.setText("Iniciar Partida");
        iniciarPartidaAlunoButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                iniciarPartidaAlunoButtonActionPerformed(evt);
            }
        });
        getContentPane().add(iniciarPartidaAlunoButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 310, 310, 60));

        GardenBackLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/TelaInicialAluno_1_1.jpg"))); // NOI18N
        getContentPane().add(GardenBackLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, -140, 1860, 1080));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void iniciarPartidaAlunoButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_iniciarPartidaAlunoButtonActionPerformed
       this.dispose();
       TelaFase1 t1= new TelaFase1();
       t1.setVisible(true);    
    }//GEN-LAST:event_iniciarPartidaAlunoButtonActionPerformed

    private void sairButtonAlunoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sairButtonAlunoActionPerformed
        this.dispose();
        TelaInicial ti= new TelaInicial();   
        ti.setVisible(true);    
    }//GEN-LAST:event_sairButtonAlunoActionPerformed

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
               new TelaNomeAluno().setVisible(true);
            }
        });
    }

  
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel GardenBackLabel;
    private javax.swing.JButton iniciarPartidaAlunoButton;
    private javax.swing.JLabel nomeAluno;
    public javax.swing.JButton sairButtonAluno;
    // End of variables declaration//GEN-END:variables
}
