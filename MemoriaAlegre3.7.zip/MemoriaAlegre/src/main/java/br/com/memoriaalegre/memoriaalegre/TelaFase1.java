
package br.com.memoriaalegre.memoriaalegre;

import java.util.Timer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.JToggleButton;

public class TelaFase1 extends javax.swing.JFrame {
    
    int contador = 0;
    int pontos = 0;
    String pontosString = String.valueOf(pontos);
    
    private ArrayList<String> cartasFrutas;
    private ArrayList<JToggleButton> botoes;
    private ArrayList<JToggleButton> Acertobotoes;
    
    private Map<String, JToggleButton> todasCartasFrutas = new HashMap<>();
    private Carta carta;

    
    public TelaFase1() {
      
        this.botoes = new ArrayList<>();
        this.Acertobotoes = new ArrayList<>();
        initComponents();
        
        PontosLabel2.setText(pontosString);
        
        // Inicializa a lista de cartas
        this.cartasFrutas = new ArrayList<>();
        cartasFrutas.add("maca");
        cartasFrutas.add("maca");
        cartasFrutas.add("banana");
        cartasFrutas.add("banana");
        cartasFrutas.add("uva");
        cartasFrutas.add("uva");

        // Embaralha as cartas ao inicializar
        Collections.shuffle(cartasFrutas);
        
    }   
    ////////////////IMPORTANTE///////////////////
    public void validarParBotoes() {
        if (contador > 1){
            ImageIcon botao1 = (ImageIcon) botoes.get(0).getIcon();
            ImageIcon botao2 = (ImageIcon) botoes.get(1).getIcon();
            String btn1String = String.valueOf(botao1);
            String btn2String = String.valueOf(botao2);
            System.out.println(btn1String);
            System.out.println(btn2String);
            if(btn1String.equals(btn2String)){
                pontos += 100;
                Acertobotoes.add(botoes.get(0));
                Acertobotoes.add(botoes.get(1));
                botoes.clear();
                JOptionPane.showMessageDialog(null, "Par Válido");
                CartaToggleButton1.setEnabled(true);
                CartaToggleButton2.setEnabled(true);
                CartaToggleButton3.setEnabled(true);
                CartaToggleButton4.setEnabled(true);
                CartaToggleButton5.setEnabled(true);
                CartaToggleButton6.setEnabled(true);
                System.out.println(pontosString);                            
                contador = 0;             
            }
            else{ 
                try {
            // Pausa a execução da thread por 3 segundos (3000 milissegundos)
            Thread.sleep(900);
        } catch (InterruptedException e) {
            // Se ocorrer uma interrupção enquanto a thread está dormindo,
            // uma exceção do tipo InterruptedException será lançada.
            e.printStackTrace();
        }
                JOptionPane.showMessageDialog(null, "Par inválido");
                virarCartas();
                botoes.clear();
                CartaToggleButton1.setEnabled(true);
                CartaToggleButton2.setEnabled(true);
                CartaToggleButton3.setEnabled(true);
                CartaToggleButton4.setEnabled(true);
                CartaToggleButton5.setEnabled(true);
                CartaToggleButton6.setEnabled(true);
                contador = 0;
            }
        }
        else{
        }

    }
    
    public void virarCartas(){
        botoes.get(0).setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/cerebro.png")));
        botoes.get(1).setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/cerebro.png")));
    }
    
    public void limitadorBotoes(){
        if (contador > 1){
           CartaToggleButton1.setEnabled(false);
           CartaToggleButton2.setEnabled(false);
           CartaToggleButton3.setEnabled(false);
           CartaToggleButton4.setEnabled(false);
           CartaToggleButton5.setEnabled(false);
           CartaToggleButton6.setEnabled(false);
        }
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        CartaToggleButton6 = new javax.swing.JToggleButton();
        CartaToggleButton4 = new javax.swing.JToggleButton();
        CartaToggleButton5 = new javax.swing.JToggleButton();
        CartaToggleButton3 = new javax.swing.JToggleButton();
        CartaToggleButton1 = new javax.swing.JToggleButton();
        CartaToggleButton2 = new javax.swing.JToggleButton();
        resetButton = new javax.swing.JButton();
        PontosLabel1 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        PontosLabel2 = new javax.swing.JLabel();
        ExitPhaseButton = new javax.swing.JButton();
        canvas1 = new java.awt.Canvas();
        frutasLabel = new javax.swing.JLabel();
        GardenLabelF1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        setFocusCycleRoot(false);
        setMinimumSize(new java.awt.Dimension(1280, 800));
        getContentPane().setLayout(null);

        CartaToggleButton6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Cerebro.png"))); // NOI18N
        CartaToggleButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CartaToggleButton6ActionPerformed(evt);
            }
        });
        getContentPane().add(CartaToggleButton6);
        CartaToggleButton6.setBounds(740, 530, 120, 150);
        todasCartasFrutas.put("CartaToggleButton6", CartaToggleButton6);
        add(CartaToggleButton6);

        CartaToggleButton4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Cerebro.png"))); // NOI18N
        CartaToggleButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CartaToggleButton4ActionPerformed(evt);
            }
        });
        getContentPane().add(CartaToggleButton4);
        CartaToggleButton4.setBounds(550, 530, 120, 150);
        todasCartasFrutas.put("CartaToggleButton4", CartaToggleButton4);
        add(CartaToggleButton4);

        CartaToggleButton5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Cerebro.png"))); // NOI18N
        CartaToggleButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CartaToggleButton5ActionPerformed(evt);
            }
        });
        getContentPane().add(CartaToggleButton5);
        CartaToggleButton5.setBounds(340, 530, 120, 150);
        todasCartasFrutas.put("CartaToggleButton5", CartaToggleButton5);
        add(CartaToggleButton5);

        CartaToggleButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Cerebro.png"))); // NOI18N
        CartaToggleButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CartaToggleButton3ActionPerformed(evt);
            }
        });
        getContentPane().add(CartaToggleButton3);
        CartaToggleButton3.setBounds(740, 310, 120, 150);
        todasCartasFrutas.put("CartaToggleButton3", CartaToggleButton3);
        add(CartaToggleButton3);

        CartaToggleButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Cerebro.png"))); // NOI18N
        CartaToggleButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CartaToggleButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(CartaToggleButton1);
        CartaToggleButton1.setBounds(340, 310, 120, 150);
        todasCartasFrutas.put("CartaToggleButton1", CartaToggleButton1);
        add(CartaToggleButton1);

        CartaToggleButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Cerebro.png"))); // NOI18N
        CartaToggleButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CartaToggleButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(CartaToggleButton2);
        CartaToggleButton2.setBounds(550, 310, 120, 150);
        todasCartasFrutas.put("CartaToggleButton2", CartaToggleButton2);
        add(CartaToggleButton2);

        resetButton.setFont(new java.awt.Font("Trebuchet MS", 1, 18)); // NOI18N
        resetButton.setText("Reset");
        resetButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                resetButtonActionPerformed(evt);
            }
        });
        getContentPane().add(resetButton);
        resetButton.setBounds(50, 110, 130, 40);

        PontosLabel1.setFont(new java.awt.Font("Trebuchet MS", 1, 48)); // NOI18N
        PontosLabel1.setText("PONTOS:");
        getContentPane().add(PontosLabel1);
        PontosLabel1.setBounds(880, 10, 210, 60);

        jLabel1.setFont(new java.awt.Font("Trebuchet MS", 1, 48)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("TEMPO:");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(20, 20, 210, 50);

        PontosLabel2.setFont(new java.awt.Font("Trebuchet MS", 1, 48)); // NOI18N
        getContentPane().add(PontosLabel2);
        PontosLabel2.setBounds(1090, 10, 190, 60);

        ExitPhaseButton.setFont(new java.awt.Font("Trebuchet MS", 1, 18)); // NOI18N
        ExitPhaseButton.setText("Sair");
        ExitPhaseButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ExitPhaseButtonActionPerformed(evt);
            }
        });
        getContentPane().add(ExitPhaseButton);
        ExitPhaseButton.setBounds(1760, 120, 130, 40);

        canvas1.setBackground(new java.awt.Color(204, 204, 204));
        getContentPane().add(canvas1);
        canvas1.setBounds(0, 100, 1960, 0);

        frutasLabel.setFont(new java.awt.Font("Trebuchet MS", 1, 70)); // NOI18N
        frutasLabel.setForeground(new java.awt.Color(255, 255, 255));
        frutasLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        frutasLabel.setText("Frutas");
        getContentPane().add(frutasLabel);
        frutasLabel.setBounds(480, 170, 240, 93);

        GardenLabelF1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/telaGame_1.jpg"))); // NOI18N
        getContentPane().add(GardenLabelF1);
        GardenLabelF1.setBounds(0, -190, 1950, 1180);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void resetButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_resetButtonActionPerformed
        CartaToggleButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/cerebro.png")));
        CartaToggleButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/cerebro.png")));
        CartaToggleButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/cerebro.png")));
        CartaToggleButton4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/cerebro.png")));
        CartaToggleButton5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/cerebro.png")));
        CartaToggleButton6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/cerebro.png")));
    }//GEN-LAST:event_resetButtonActionPerformed

    private void ExitPhaseButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ExitPhaseButtonActionPerformed
     TelaEntrarNomeAluno tena= new TelaEntrarNomeAluno();
     tena.setVisible(true);
    }//GEN-LAST:event_ExitPhaseButtonActionPerformed

    private void CartaToggleButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CartaToggleButton6ActionPerformed
    if (CartaToggleButton6.isSelected()){
        CartaToggleButton6.setEnabled(false);
        limitadorBotoes();
        contador ++;
        CartaToggleButton6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/" + cartasFrutas.get(5) + ".png")));
        botoes.add(CartaToggleButton6);
        validarParBotoes();      
    }
    }//GEN-LAST:event_CartaToggleButton6ActionPerformed

    private void CartaToggleButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CartaToggleButton1ActionPerformed
    if (CartaToggleButton1.isSelected()){
        CartaToggleButton1.setEnabled(false);
        limitadorBotoes();
        contador ++;
        CartaToggleButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/" + cartasFrutas.get(0) + ".png")));
        botoes.add(CartaToggleButton1);
        validarParBotoes();
    }
    }//GEN-LAST:event_CartaToggleButton1ActionPerformed

    private void CartaToggleButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CartaToggleButton2ActionPerformed
    if (CartaToggleButton2.isSelected()){
        CartaToggleButton2.setEnabled(false);
        limitadorBotoes();
        contador ++;
        CartaToggleButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/" + cartasFrutas.get(1) + ".png")));
        botoes.add(CartaToggleButton2);
        validarParBotoes();
    }
    }//GEN-LAST:event_CartaToggleButton2ActionPerformed
 
    private void CartaToggleButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CartaToggleButton5ActionPerformed
    if (CartaToggleButton5.isSelected()){
        CartaToggleButton5.setEnabled(false);
        limitadorBotoes();
        contador ++;
        CartaToggleButton5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/" + cartasFrutas.get(4) + ".png")));
        botoes.add(CartaToggleButton5);
        validarParBotoes();
    }
    }//GEN-LAST:event_CartaToggleButton5ActionPerformed

    private void CartaToggleButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CartaToggleButton4ActionPerformed
    if (CartaToggleButton4.isSelected()){
        CartaToggleButton4.setEnabled(false);
        limitadorBotoes();
        contador ++;
        CartaToggleButton4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/" + cartasFrutas.get(3) + ".png")));
        botoes.add(CartaToggleButton4);
        validarParBotoes();
    }
    }//GEN-LAST:event_CartaToggleButton4ActionPerformed

    private void CartaToggleButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CartaToggleButton3ActionPerformed
    if (CartaToggleButton3.isSelected()){
        CartaToggleButton3.setEnabled(false);
        limitadorBotoes();
        contador ++;
        CartaToggleButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/" + cartasFrutas.get(2) + ".png")));
        botoes.add(CartaToggleButton3);
        validarParBotoes();
    }
    }//GEN-LAST:event_CartaToggleButton3ActionPerformed
    
    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TelaFase1().setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    public javax.swing.JToggleButton CartaToggleButton1;
    public javax.swing.JToggleButton CartaToggleButton2;
    public javax.swing.JToggleButton CartaToggleButton3;
    public javax.swing.JToggleButton CartaToggleButton4;
    public javax.swing.JToggleButton CartaToggleButton5;
    public javax.swing.JToggleButton CartaToggleButton6;
    private javax.swing.JButton ExitPhaseButton;
    private javax.swing.JLabel GardenLabelF1;
    private javax.swing.JLabel PontosLabel1;
    private javax.swing.JLabel PontosLabel2;
    private java.awt.Canvas canvas1;
    private javax.swing.JLabel frutasLabel;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JButton resetButton;
    // End of variables declaration//GEN-END:variables
}
