/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package control;

/**
 *
 * @author Murilo
 */
public class Controlador {
    
    private static String nome;

    public static String getNome() {
        return nome;
    }

    public static void setNome(String novoNome) {
        nome = novoNome;
    }
}
