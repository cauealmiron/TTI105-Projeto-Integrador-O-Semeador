

package br.com.memoriaalegre.memoriaalegre;
import control.Controlador;
public class TelaEntrarNomeAluno extends javax.swing.JFrame {;

       public TelaEntrarNomeAluno() {
        initComponents();
        
        nomeAluno.setText("Bem vindo, " + Controlador.getNome()+ "!" );
        //bemVindoNomeAlunoLabel.setText("Bem-vindo!");
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        nomeAluno = new javax.swing.JLabel();
        sairButtonAluno = new javax.swing.JButton();
        iniciarPartidaAlunoButton = new javax.swing.JButton();
        GardenBackLabel = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        nomeAluno.setFont(new java.awt.Font("Trebuchet MS", 1, 18)); // NOI18N
        nomeAluno.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        nomeAluno.setToolTipText("");
        getContentPane().add(nomeAluno, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 240, 460, 40));

        sairButtonAluno.setFont(new java.awt.Font("Trebuchet MS", 1, 36)); // NOI18N
        sairButtonAluno.setText("Sair");
        sairButtonAluno.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED, null, java.awt.Color.lightGray, null, null));
        sairButtonAluno.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sairButtonAlunoActionPerformed(evt);
            }
        });
        getContentPane().add(sairButtonAluno, new org.netbeans.lib.awtextra.AbsoluteConstraints(790, 580, 370, 80));

        iniciarPartidaAlunoButton.setFont(new java.awt.Font("Trebuchet MS", 1, 36)); // NOI18N
        iniciarPartidaAlunoButton.setText("Iniciar Partida");
        iniciarPartidaAlunoButton.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED, null, java.awt.Color.lightGray, null, null));
        iniciarPartidaAlunoButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                iniciarPartidaAlunoButtonActionPerformed(evt);
            }
        });
        getContentPane().add(iniciarPartidaAlunoButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(790, 420, 370, 80));

        GardenBackLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/TelaInicialAluno_1.jpg"))); // NOI18N
        getContentPane().add(GardenBackLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 0, 1920, 1080));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void iniciarPartidaAlunoButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_iniciarPartidaAlunoButtonActionPerformed
        
       TelaFase1 t1= new TelaFase1();
       t1.setVisible(true);    
                dispose(); // Fecha a janela atual
                // TelaEntrarNomeAluno(nomeAluno); // Exibe a tela de boas-vindas com o nome do aluno;;
            
         
    }//GEN-LAST:event_iniciarPartidaAlunoButtonActionPerformed

    private void sairButtonAlunoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sairButtonAlunoActionPerformed
        this.dispose();
        TelaInicial ti= new TelaInicial();   
        ti.setVisible(true);
        
    }//GEN-LAST:event_sairButtonAlunoActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TelaEntrarNomeAluno.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TelaEntrarNomeAluno.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TelaEntrarNomeAluno.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TelaEntrarNomeAluno.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
               new TelaEntrarNomeAluno().setVisible(true);
            }
        });
    }

  
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel GardenBackLabel;
    private javax.swing.JButton iniciarPartidaAlunoButton;
    private javax.swing.JLabel nomeAluno;
    public javax.swing.JButton sairButtonAluno;
    // End of variables declaration//GEN-END:variables
}
