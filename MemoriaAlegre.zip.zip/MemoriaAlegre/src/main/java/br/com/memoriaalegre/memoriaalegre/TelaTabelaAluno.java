
package br.com.memoriaalegre.memoriaalegre;

public class TelaTabelaAluno extends javax.swing.JFrame {

    public TelaTabelaAluno() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        TabelaPontuação = new javax.swing.JTable();
        VoltarTabelaButton = new javax.swing.JButton();
        TextoTabela = new javax.swing.JLabel();
        TabelaLabel = new javax.swing.JLabel();
        GardenTELabel = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMaximizedBounds(new java.awt.Rectangle(0, 0, 1920, 1080));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        TabelaPontuação.setBackground(new java.awt.Color(204, 204, 204));
        TabelaPontuação.setFont(new java.awt.Font("Trebuchet MS", 1, 24)); // NOI18N
        TabelaPontuação.setForeground(new java.awt.Color(255, 255, 255));
        TabelaPontuação.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Nome", "Pontuação", "Tempo", "Turma"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.Integer.class, java.lang.Double.class, java.lang.Integer.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        TabelaPontuação.setToolTipText("");
        TabelaPontuação.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        TabelaPontuação.setGridColor(new java.awt.Color(255, 255, 255));
        TabelaPontuação.setName(""); // NOI18N
        TabelaPontuação.setRequestFocusEnabled(false);
        TabelaPontuação.setRowHeight(70);
        TabelaPontuação.setShowGrid(false);
        TabelaPontuação.setShowHorizontalLines(true);
        jScrollPane1.setViewportView(TabelaPontuação);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 270, 1440, 650));

        VoltarTabelaButton.setFont(new java.awt.Font("Trebuchet MS", 1, 20)); // NOI18N
        VoltarTabelaButton.setText("Voltar");
        VoltarTabelaButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                VoltarTabelaButtonActionPerformed(evt);
            }
        });
        getContentPane().add(VoltarTabelaButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(870, 960, 170, 40));

        TextoTabela.setFont(new java.awt.Font("Trebuchet MS", 1, 60)); // NOI18N
        TextoTabela.setText("Tabela de Pontuações");
        getContentPane().add(TextoTabela, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 180, 640, -1));

        TabelaLabel.setBackground(new java.awt.Color(255, 255, 255));
        TabelaLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/telattabela.jpg"))); // NOI18N
        getContentPane().add(TabelaLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1920, 1080));

        GardenTELabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/GardenMA.png"))); // NOI18N
        getContentPane().add(GardenTELabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1920, 1080));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void VoltarTabelaButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_VoltarTabelaButtonActionPerformed
        this.dispose();
        TelaInicial ti = new TelaInicial();
        ti.setVisible(true);
        
    }//GEN-LAST:event_VoltarTabelaButtonActionPerformed

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TelaTabelaAluno().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel GardenTELabel;
    private javax.swing.JLabel TabelaLabel;
    private javax.swing.JTable TabelaPontuação;
    private javax.swing.JLabel TextoTabela;
    private javax.swing.JButton VoltarTabelaButton;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
