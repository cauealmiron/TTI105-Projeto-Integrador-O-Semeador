
package br.com.memoriaalegre.memoriaalegre;

public class TelaFase1 extends javax.swing.JFrame {

    public TelaFase1() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        resetButton = new javax.swing.JButton();
        FrutasCard6 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        ExitPhaseButton = new javax.swing.JButton();
        canvas1 = new java.awt.Canvas();
        FrutasCard5 = new javax.swing.JButton();
        FrutasCard4 = new javax.swing.JButton();
        FrutasCard3 = new javax.swing.JButton();
        FrutasCard2 = new javax.swing.JButton();
        FrutasCard1 = new javax.swing.JButton();
        frutasLabel = new javax.swing.JLabel();
        GardenLabelF1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(1920, 1080));
        getContentPane().setLayout(null);

        resetButton.setFont(new java.awt.Font("Trebuchet MS", 1, 18)); // NOI18N
        resetButton.setText("Reset");
        resetButton.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        resetButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                resetButtonActionPerformed(evt);
            }
        });
        getContentPane().add(resetButton);
        resetButton.setBounds(30, 120, 130, 40);

        FrutasCard6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Cerebro.png"))); // NOI18N
        FrutasCard6.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        FrutasCard6.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        FrutasCard6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                FrutasCard6ActionPerformed(evt);
            }
        });
        getContentPane().add(FrutasCard6);
        FrutasCard6.setBounds(1050, 610, 150, 190);

        jLabel1.setFont(new java.awt.Font("Trebuchet MS", 1, 48)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("TEMPO:");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(20, 30, 210, 50);

        ExitPhaseButton.setFont(new java.awt.Font("Trebuchet MS", 1, 18)); // NOI18N
        ExitPhaseButton.setText("Sair");
        ExitPhaseButton.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        ExitPhaseButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ExitPhaseButtonActionPerformed(evt);
            }
        });
        getContentPane().add(ExitPhaseButton);
        ExitPhaseButton.setBounds(1760, 120, 130, 40);

        canvas1.setBackground(new java.awt.Color(204, 204, 204));
        getContentPane().add(canvas1);
        canvas1.setBounds(0, 100, 1960, 0);

        FrutasCard5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Cerebro.png"))); // NOI18N
        FrutasCard5.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        FrutasCard5.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        FrutasCard5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                FrutasCard5ActionPerformed(evt);
            }
        });
        getContentPane().add(FrutasCard5);
        FrutasCard5.setBounds(850, 610, 150, 190);

        FrutasCard4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Cerebro.png"))); // NOI18N
        FrutasCard4.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        FrutasCard4.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        FrutasCard4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                FrutasCard4ActionPerformed(evt);
            }
        });
        getContentPane().add(FrutasCard4);
        FrutasCard4.setBounds(650, 610, 150, 190);

        FrutasCard3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Cerebro.png"))); // NOI18N
        FrutasCard3.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        FrutasCard3.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        FrutasCard3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                FrutasCard3ActionPerformed(evt);
            }
        });
        getContentPane().add(FrutasCard3);
        FrutasCard3.setBounds(1050, 400, 150, 190);

        FrutasCard2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Cerebro.png"))); // NOI18N
        FrutasCard2.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        FrutasCard2.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        FrutasCard2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                FrutasCard2ActionPerformed(evt);
            }
        });
        getContentPane().add(FrutasCard2);
        FrutasCard2.setBounds(850, 400, 150, 190);

        FrutasCard1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Cerebro.png"))); // NOI18N
        FrutasCard1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        FrutasCard1.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        FrutasCard1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                FrutasCard1ActionPerformed(evt);
            }
        });
        getContentPane().add(FrutasCard1);
        FrutasCard1.setBounds(650, 400, 150, 190);

        frutasLabel.setFont(new java.awt.Font("Trebuchet MS", 1, 70)); // NOI18N
        frutasLabel.setForeground(new java.awt.Color(255, 255, 255));
        frutasLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        frutasLabel.setText("Frutas");
        getContentPane().add(frutasLabel);
        frutasLabel.setBounds(810, 270, 240, 93);

        GardenLabelF1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/telaGame.jpg"))); // NOI18N
        getContentPane().add(GardenLabelF1);
        GardenLabelF1.setBounds(10, -40, 1950, 1180);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void FrutasCard4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_FrutasCard4ActionPerformed
        FrutasCard4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/banana.png")));       
    }//GEN-LAST:event_FrutasCard4ActionPerformed

    private void FrutasCard1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_FrutasCard1ActionPerformed
        FrutasCard1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/maca.png")));
    }//GEN-LAST:event_FrutasCard1ActionPerformed

    private void FrutasCard6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_FrutasCard6ActionPerformed
        FrutasCard6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/maca.png")));
    }//GEN-LAST:event_FrutasCard6ActionPerformed

    private void FrutasCard2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_FrutasCard2ActionPerformed
        FrutasCard2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/banana.png")));
    }//GEN-LAST:event_FrutasCard2ActionPerformed

    private void FrutasCard3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_FrutasCard3ActionPerformed
        FrutasCard3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/uva.png")));
    }//GEN-LAST:event_FrutasCard3ActionPerformed

    private void FrutasCard5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_FrutasCard5ActionPerformed
        FrutasCard5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/uva.png")));
    }//GEN-LAST:event_FrutasCard5ActionPerformed

    private void resetButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_resetButtonActionPerformed
        FrutasCard1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/cerebro.png")));
        FrutasCard2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/cerebro.png")));
        FrutasCard3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/cerebro.png")));
        FrutasCard4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/cerebro.png")));
        FrutasCard5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/cerebro.png")));
        FrutasCard6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/cerebro.png")));
    }//GEN-LAST:event_resetButtonActionPerformed

    private void ExitPhaseButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ExitPhaseButtonActionPerformed
     TelaEntrarNomeAluno tena= new TelaEntrarNomeAluno();
     tena.setVisible(true);// TODO add your handling code here:
    }//GEN-LAST:event_ExitPhaseButtonActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TelaFase1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TelaFase1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TelaFase1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TelaFase1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TelaFase1().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton ExitPhaseButton;
    private javax.swing.JButton FrutasCard1;
    private javax.swing.JButton FrutasCard2;
    private javax.swing.JButton FrutasCard3;
    private javax.swing.JButton FrutasCard4;
    private javax.swing.JButton FrutasCard5;
    private javax.swing.JButton FrutasCard6;
    private javax.swing.JLabel GardenLabelF1;
    private java.awt.Canvas canvas1;
    private javax.swing.JLabel frutasLabel;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JButton resetButton;
    // End of variables declaration//GEN-END:variables
}
