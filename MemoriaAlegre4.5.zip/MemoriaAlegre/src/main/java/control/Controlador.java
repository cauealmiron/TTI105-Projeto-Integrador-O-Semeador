package control;


public class Controlador {
    
    private static String nome;

    public int getPontos() {
        return pontos;
    }

    public void setPontos(int pontos) {
        this.pontos = pontos;
    }
    private int pontos;

    public static String getNome() {
        return nome;
    }

    public static void setNome(String novoNome) {
        nome = novoNome;
    }
}

