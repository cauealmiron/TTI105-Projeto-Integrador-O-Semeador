package br.com.memoriaalegre.memoriaalegre;
/**
 *
 * @author Gustavo
 */
import control.Controlador;

import java.awt.event.*;
import javax.swing.JOptionPane;
public class TelaConfigurações extends javax.swing.JFrame {

    public TelaConfigurações() {
        initComponents();
        setLocationRelativeTo(null);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        nomeAlunoTextField = new javax.swing.JTextField();
        NomeAlunoLabel = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        TempoComboBox = new javax.swing.JComboBox<>();
        TemaComboBox = new javax.swing.JComboBox<>();
        EntrarFaseButton = new javax.swing.JButton();
        SairButton = new javax.swing.JButton();
        ConsultarButton = new javax.swing.JButton();
        ConfigLabel = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(1280, 800));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        nomeAlunoTextField.setFont(new java.awt.Font("Trebuchet MS", 1, 20)); // NOI18N
        nomeAlunoTextField.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED, null, java.awt.Color.lightGray, null, null));
        nomeAlunoTextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nomeAlunoTextFieldActionPerformed(evt);
            }
        });
        getContentPane().add(nomeAlunoTextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 300, 380, 30));

        NomeAlunoLabel.setFont(new java.awt.Font("Trebuchet MS", 1, 24)); // NOI18N
        NomeAlunoLabel.setText("Nome Aluno ");
        getContentPane().add(NomeAlunoLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 250, 150, 30));

        jLabel5.setFont(new java.awt.Font("Trebuchet MS", 1, 24)); // NOI18N
        jLabel5.setText("Tema");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 390, 80, 30));

        jLabel4.setFont(new java.awt.Font("Trebuchet MS", 1, 24)); // NOI18N
        jLabel4.setText("Tempo");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 520, 80, 30));

        TempoComboBox.setFont(new java.awt.Font("Trebuchet MS", 1, 20)); // NOI18N
        TempoComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "2 Minutos", "5 Minutos", "7 Minutos" }));
        TempoComboBox.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED, null, java.awt.Color.lightGray, null, null));
        TempoComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TempoComboBoxActionPerformed(evt);
            }
        });
        getContentPane().add(TempoComboBox, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 560, 380, 30));

        TemaComboBox.setFont(new java.awt.Font("Trebuchet MS", 1, 20)); // NOI18N
        TemaComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Frutas", "Figuras", "Números" }));
        TemaComboBox.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED, null, java.awt.Color.lightGray, null, null));
        TemaComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TemaComboBoxActionPerformed(evt);
            }
        });
        getContentPane().add(TemaComboBox, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 430, 380, 30));

        EntrarFaseButton.setFont(new java.awt.Font("Trebuchet MS", 1, 18)); // NOI18N
        EntrarFaseButton.setText("Entrar");
        EntrarFaseButton.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED, null, java.awt.Color.lightGray, null, null));
        EntrarFaseButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EntrarFaseButtonActionPerformed(evt);
            }
        });
        getContentPane().add(EntrarFaseButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(850, 610, 100, 40));

        SairButton.setFont(new java.awt.Font("Trebuchet MS", 1, 18)); // NOI18N
        SairButton.setText("Voltar");
        SairButton.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED, null, java.awt.Color.lightGray, null, null));
        SairButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SairButtonActionPerformed(evt);
            }
        });
        getContentPane().add(SairButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 700, 100, 40));

        ConsultarButton.setFont(new java.awt.Font("Trebuchet MS", 1, 18)); // NOI18N
        ConsultarButton.setText("Consultar Pontuação ");
        ConsultarButton.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED, null, java.awt.Color.lightGray, null, null));
        ConsultarButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ConsultarButtonActionPerformed(evt);
            }
        });
        getContentPane().add(ConsultarButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 700, 190, 40));

        ConfigLabel.setBackground(new java.awt.Color(0, 0, 0));
        ConfigLabel.setFont(new java.awt.Font("Trebuchet MS", 0, 48)); // NOI18N
        ConfigLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        ConfigLabel.setText("Configurações");
        ConfigLabel.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        ConfigLabel.setDebugGraphicsOptions(javax.swing.DebugGraphics.NONE_OPTION);
        ConfigLabel.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        getContentPane().add(ConfigLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 150, 330, 60));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/TelaConfig_1_1.jpg"))); // NOI18N
        jLabel1.setMaximumSize(null);
        jLabel1.setMinimumSize(null);
        jLabel1.setPreferredSize(null);
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, -140, 1280, 1080));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void SairButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SairButtonActionPerformed
    TelaInicial ti= new TelaInicial();
    ti.setVisible(true);
    }//GEN-LAST:event_SairButtonActionPerformed

    private void ConsultarButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ConsultarButtonActionPerformed
    this.dispose();
    TelaTabelaProfessor tltp= new TelaTabelaProfessor();
    tltp.setVisible(true);
    }//GEN-LAST:event_ConsultarButtonActionPerformed

    private void EntrarFaseButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EntrarFaseButtonActionPerformed
    this.dispose();
    String nome = nomeAlunoTextField.getText();
    Controlador.setNome(nome);
    String Tema = (String) TemaComboBox.getSelectedItem();
    String Tempo = (String) TempoComboBox.getSelectedItem();
    if ("Frutas".equals(Tema)){
     TelaNomeAlunoFrutas tena = new TelaNomeAlunoFrutas();
     tena.setVisible(true); 
    }
    else if ("Figuras".equals(Tema)){
     TelaNomeAlunoFiguras tenaf = new TelaNomeAlunoFiguras();
     tenaf.setVisible(true);
    }
    else {
     TelaNomeAlunoNumeros tenan = new TelaNomeAlunoNumeros();
     tenan.setVisible(true);
    }
    if ("2 Minutos".equals(Tempo)){
     TelaFase1.TempoLabel2.setText("2:00");
     TelaFase2.TempoLabel2.setText("2:00");
     TelaFase3.TempoLabel2.setText("2:00");
    }
    else if ("5 Minutos".equals(Tempo)){
     TelaFase1.TempoLabel2.setText("5:00");
     TelaFase2.TempoLabel2.setText("5:00");
     TelaFase3.TempoLabel2.setText("5:00");
    }
    else {
     TelaFase1.TempoLabel2.setText("7:00");
     TelaFase2.TempoLabel2.setText("7:00");
     TelaFase3.TempoLabel2.setText("7:00");
    }
    }//GEN-LAST:event_EntrarFaseButtonActionPerformed

    private void nomeAlunoTextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nomeAlunoTextFieldActionPerformed

    }//GEN-LAST:event_nomeAlunoTextFieldActionPerformed

    private void TempoComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TempoComboBoxActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TempoComboBoxActionPerformed

    private void TemaComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TemaComboBoxActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TemaComboBoxActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TelaConfigurações.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TelaConfigurações.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TelaConfigurações.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TelaConfigurações.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TelaConfigurações().setVisible(true);
            }
        });
    }
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel ConfigLabel;
    private javax.swing.JButton ConsultarButton;
    public javax.swing.JButton EntrarFaseButton;
    private javax.swing.JLabel NomeAlunoLabel;
    private javax.swing.JButton SairButton;
    private javax.swing.JComboBox<String> TemaComboBox;
    private javax.swing.JComboBox<String> TempoComboBox;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    public javax.swing.JTextField nomeAlunoTextField;
    // End of variables declaration//GEN-END:variables
}
