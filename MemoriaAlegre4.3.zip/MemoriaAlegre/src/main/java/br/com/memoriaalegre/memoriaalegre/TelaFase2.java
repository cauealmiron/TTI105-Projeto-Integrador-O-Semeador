package br.com.memoriaalegre.memoriaalegre;

import java.util.Timer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.JToggleButton;

public class TelaFase2 extends javax.swing.JFrame {
    
    int contador = 0;
    int pontos = 0;
    String pontosString = String.valueOf(pontos);
    
    private ArrayList<String> cartasFiguras;
    private ArrayList<JToggleButton> botoes;
    private ArrayList<JToggleButton> Acertobotoes;
    private ArrayList<JToggleButton> contadorCartasFigura;
    
    private Map<String, JToggleButton> todasCartasFiguras = new HashMap<>();
    private Carta carta;
    
    
    public TelaFase2() {
        
        this.contadorCartasFigura = new ArrayList<>();
        this.botoes = new ArrayList<>();
        this.Acertobotoes = new ArrayList<>();
        initComponents();
        PontosLabel2.setText(pontosString);
        
        // Inicializa a lista de cartas
        this.cartasFiguras = new ArrayList<>();
        cartasFiguras.add("piramide");
        cartasFiguras.add("piramide");
        cartasFiguras.add("cubo");
        cartasFiguras.add("cubo");
        cartasFiguras.add("circulo");
        cartasFiguras.add("circulo");
        
        // Embaralha as cartas ao inicializar
        Collections.shuffle(cartasFiguras);
    }
    
        public void validarParBotoes() {
        if (contador > 1){
            ImageIcon botao1 = (ImageIcon) botoes.get(0).getIcon();
            ImageIcon botao2 = (ImageIcon) botoes.get(1).getIcon();
            String btn1String = String.valueOf(botao1);
            String btn2String = String.valueOf(botao2);
            System.out.println(btn1String);
            System.out.println(btn2String);
            if(btn1String.equals(btn2String)){
                pontos += 100;
                Acertobotoes.add(botoes.get(0));
                Acertobotoes.add(botoes.get(1));
                contadorCartasFigura.add(botoes.get(0));
                contadorCartasFigura.add(botoes.get(1));
                botoes.clear();
                JOptionPane.showMessageDialog(null, "Par Válido");
                CartaToggleButton1.setEnabled(true);
                CartaToggleButton2.setEnabled(true);
                CartaToggleButton3.setEnabled(true);
                CartaToggleButton4.setEnabled(true);
                CartaToggleButton5.setEnabled(true);
                CartaToggleButton6.setEnabled(true);
                System.out.println(pontosString);                            
                contador = 0;
                pontosString = String.valueOf(pontos);
                PontosLabel2.setText(pontosString);
            }
            else{ 
                try {            
            Thread.sleep(000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
                JOptionPane.showMessageDialog(null, "Par inválido");
                virarCartas();
                botoes.clear();
                CartaToggleButton1.setEnabled(true);
                CartaToggleButton2.setEnabled(true);
                CartaToggleButton3.setEnabled(true);
                CartaToggleButton4.setEnabled(true);
                CartaToggleButton5.setEnabled(true);
                CartaToggleButton6.setEnabled(true);
                contador = 0;
            }
        }
        else{
        }

    }
    
    public void virarCartas(){
        botoes.get(0).setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/cerebro.png")));
        botoes.get(1).setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/cerebro.png")));
    }
    
    public void limitadorBotoes(){
        if (contador > 1){
           CartaToggleButton1.setEnabled(false);
           CartaToggleButton2.setEnabled(false);
           CartaToggleButton3.setEnabled(false);
           CartaToggleButton4.setEnabled(false);
           CartaToggleButton5.setEnabled(false);
           CartaToggleButton6.setEnabled(false);
        }
    }
    
    public void reiniciarCartas(){
        if (contadorCartasFigura.size()  == 6){
              
              contadorCartasFigura.clear();
              
              Collections.shuffle(cartasFiguras);
              
              CartaToggleButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/cerebro.png")));
              CartaToggleButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/cerebro.png")));
              CartaToggleButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/cerebro.png")));
              CartaToggleButton4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/cerebro.png")));
              CartaToggleButton5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/cerebro.png")));
              CartaToggleButton6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/cerebro.png")));
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        PontosLabel2 = new javax.swing.JLabel();
        PontosLabel1 = new javax.swing.JLabel();
        TempoLabel1 = new javax.swing.JLabel();
        CartaToggleButton6 = new javax.swing.JToggleButton();
        CartaToggleButton5 = new javax.swing.JToggleButton();
        CartaToggleButton4 = new javax.swing.JToggleButton();
        CartaToggleButton3 = new javax.swing.JToggleButton();
        CartaToggleButton2 = new javax.swing.JToggleButton();
        CartaToggleButton1 = new javax.swing.JToggleButton();
        FigutasLabel = new javax.swing.JLabel();
        GardenLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMaximumSize(new java.awt.Dimension(1280, 800));
        setMinimumSize(new java.awt.Dimension(1280, 800));
        getContentPane().setLayout(null);

        PontosLabel2.setFont(new java.awt.Font("Trebuchet MS", 1, 48)); // NOI18N
        getContentPane().add(PontosLabel2);
        PontosLabel2.setBounds(1090, 10, 180, 60);

        PontosLabel1.setFont(new java.awt.Font("Trebuchet MS", 1, 48)); // NOI18N
        PontosLabel1.setText("PONTOS: ");
        getContentPane().add(PontosLabel1);
        PontosLabel1.setBounds(880, 10, 220, 60);

        TempoLabel1.setFont(new java.awt.Font("Trebuchet MS", 1, 48)); // NOI18N
        TempoLabel1.setText("TEMPO: ");
        getContentPane().add(TempoLabel1);
        TempoLabel1.setBounds(10, 10, 190, 60);

        CartaToggleButton6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Cerebro.png"))); // NOI18N
        CartaToggleButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CartaToggleButton6ActionPerformed(evt);
            }
        });
        getContentPane().add(CartaToggleButton6);
        CartaToggleButton6.setBounds(790, 530, 120, 150);

        CartaToggleButton5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Cerebro.png"))); // NOI18N
        CartaToggleButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CartaToggleButton5ActionPerformed(evt);
            }
        });
        getContentPane().add(CartaToggleButton5);
        CartaToggleButton5.setBounds(570, 530, 120, 150);

        CartaToggleButton4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Cerebro.png"))); // NOI18N
        CartaToggleButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CartaToggleButton4ActionPerformed(evt);
            }
        });
        getContentPane().add(CartaToggleButton4);
        CartaToggleButton4.setBounds(340, 530, 120, 150);

        CartaToggleButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Cerebro.png"))); // NOI18N
        CartaToggleButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CartaToggleButton3ActionPerformed(evt);
            }
        });
        getContentPane().add(CartaToggleButton3);
        CartaToggleButton3.setBounds(790, 310, 120, 150);

        CartaToggleButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Cerebro.png"))); // NOI18N
        CartaToggleButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CartaToggleButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(CartaToggleButton2);
        CartaToggleButton2.setBounds(570, 310, 120, 150);

        CartaToggleButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Cerebro.png"))); // NOI18N
        CartaToggleButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CartaToggleButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(CartaToggleButton1);
        CartaToggleButton1.setBounds(340, 310, 120, 150);

        FigutasLabel.setFont(new java.awt.Font("Trebuchet MS", 1, 54)); // NOI18N
        FigutasLabel.setForeground(new java.awt.Color(255, 255, 255));
        FigutasLabel.setText("Figuras");
        getContentPane().add(FigutasLabel);
        FigutasLabel.setBounds(540, 140, 190, 110);

        GardenLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/telaGame_1.jpg"))); // NOI18N
        getContentPane().add(GardenLabel2);
        GardenLabel2.setBounds(0, 0, 1280, 800);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void CartaToggleButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CartaToggleButton1ActionPerformed
    if (CartaToggleButton1.isSelected()){
        CartaToggleButton1.setEnabled(false);
        limitadorBotoes();
        contador ++;
        CartaToggleButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/" + cartasFiguras.get(0) + ".png")));
        botoes.add(CartaToggleButton1);
        reiniciarCartas();
        validarParBotoes();      
    }
    }//GEN-LAST:event_CartaToggleButton1ActionPerformed

    private void CartaToggleButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CartaToggleButton2ActionPerformed
    if (CartaToggleButton2.isSelected()){
        CartaToggleButton2.setEnabled(false);
        limitadorBotoes();
        contador ++;
        CartaToggleButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/" + cartasFiguras.get(1) + ".png")));
        botoes.add(CartaToggleButton2);
        reiniciarCartas();
        validarParBotoes();      
    }
    }//GEN-LAST:event_CartaToggleButton2ActionPerformed

    private void CartaToggleButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CartaToggleButton3ActionPerformed
    if (CartaToggleButton3.isSelected()){
        CartaToggleButton3.setEnabled(false);
        limitadorBotoes();
        contador ++;
        CartaToggleButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/" + cartasFiguras.get(2) + ".png")));
        botoes.add(CartaToggleButton3);
        reiniciarCartas();
        validarParBotoes();      
    }
    }//GEN-LAST:event_CartaToggleButton3ActionPerformed

    private void CartaToggleButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CartaToggleButton4ActionPerformed
    if (CartaToggleButton4.isSelected()){
        CartaToggleButton4.setEnabled(false);
        limitadorBotoes();
        contador ++;
        CartaToggleButton4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/" + cartasFiguras.get(3) + ".png")));
        botoes.add(CartaToggleButton4);
        reiniciarCartas();
        validarParBotoes();      
    }
    }//GEN-LAST:event_CartaToggleButton4ActionPerformed

    private void CartaToggleButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CartaToggleButton5ActionPerformed
    if (CartaToggleButton5.isSelected()){
        CartaToggleButton5.setEnabled(false);
        limitadorBotoes();
        contador ++;
        CartaToggleButton5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/" + cartasFiguras.get(4) + ".png")));
        botoes.add(CartaToggleButton5);
        reiniciarCartas();
        validarParBotoes();      
    }
    }//GEN-LAST:event_CartaToggleButton5ActionPerformed

    private void CartaToggleButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CartaToggleButton6ActionPerformed
    if (CartaToggleButton6.isSelected()){
        CartaToggleButton6.setEnabled(false);
        limitadorBotoes();
        contador ++;
        CartaToggleButton6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/" + cartasFiguras.get(5) + ".png")));
        botoes.add(CartaToggleButton6);
        reiniciarCartas();
        validarParBotoes();      
    }
    }//GEN-LAST:event_CartaToggleButton6ActionPerformed

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TelaFase2().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JToggleButton CartaToggleButton1;
    private javax.swing.JToggleButton CartaToggleButton2;
    private javax.swing.JToggleButton CartaToggleButton3;
    private javax.swing.JToggleButton CartaToggleButton4;
    private javax.swing.JToggleButton CartaToggleButton5;
    private javax.swing.JToggleButton CartaToggleButton6;
    private javax.swing.JLabel FigutasLabel;
    private javax.swing.JLabel GardenLabel2;
    private javax.swing.JLabel PontosLabel1;
    private javax.swing.JLabel PontosLabel2;
    private javax.swing.JLabel TempoLabel1;
    // End of variables declaration//GEN-END:variables
}
