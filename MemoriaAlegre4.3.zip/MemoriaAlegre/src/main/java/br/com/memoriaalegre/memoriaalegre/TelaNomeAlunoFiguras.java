package br.com.memoriaalegre.memoriaalegre;

import control.Controlador;

public class TelaNomeAlunoFiguras extends javax.swing.JFrame {

    public TelaNomeAlunoFiguras() {
        initComponents();       
        nomeAluno.setText("Bem vindo, " + Controlador.getNome()+ "!" );
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        iniciarPartidaAlunoButton = new javax.swing.JButton();
        sairButtonAluno = new javax.swing.JButton();
        nomeAluno = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(1280, 800));
        getContentPane().setLayout(null);

        iniciarPartidaAlunoButton.setFont(new java.awt.Font("Trebuchet MS", 1, 36)); // NOI18N
        iniciarPartidaAlunoButton.setText("Iniciar Partida");
        iniciarPartidaAlunoButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                iniciarPartidaAlunoButtonActionPerformed(evt);
            }
        });
        getContentPane().add(iniciarPartidaAlunoButton);
        iniciarPartidaAlunoButton.setBounds(490, 300, 300, 60);

        sairButtonAluno.setFont(new java.awt.Font("Trebuchet MS", 1, 36)); // NOI18N
        sairButtonAluno.setText("Sair");
        sairButtonAluno.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sairButtonAlunoActionPerformed(evt);
            }
        });
        getContentPane().add(sairButtonAluno);
        sairButtonAluno.setBounds(500, 450, 270, 60);

        nomeAluno.setFont(new java.awt.Font("Trebuchet MS", 1, 36)); // NOI18N
        nomeAluno.setForeground(new java.awt.Color(255, 255, 255));
        nomeAluno.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        nomeAluno.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        getContentPane().add(nomeAluno);
        nomeAluno.setBounds(410, 130, 460, 60);

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/TelaInicialAluno_1_1.jpg"))); // NOI18N
        getContentPane().add(jLabel1);
        jLabel1.setBounds(0, 0, 1280, 800);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void iniciarPartidaAlunoButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_iniciarPartidaAlunoButtonActionPerformed
        this.dispose();
        TelaFase2 t2 = new TelaFase2();
        t2.setVisible(true);
    }//GEN-LAST:event_iniciarPartidaAlunoButtonActionPerformed

    private void sairButtonAlunoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sairButtonAlunoActionPerformed
        this.dispose();
        TelaInicial ti= new TelaInicial();
        ti.setVisible(true);
    }//GEN-LAST:event_sairButtonAlunoActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TelaNomeAlunoFiguras.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TelaNomeAlunoFiguras.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TelaNomeAlunoFiguras.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TelaNomeAlunoFiguras.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TelaNomeAlunoFiguras().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton iniciarPartidaAlunoButton;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel nomeAluno;
    public javax.swing.JButton sairButtonAluno;
    // End of variables declaration//GEN-END:variables
}
