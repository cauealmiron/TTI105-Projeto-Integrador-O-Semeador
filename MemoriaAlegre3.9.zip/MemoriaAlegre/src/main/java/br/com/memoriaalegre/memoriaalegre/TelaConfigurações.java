package br.com.memoriaalegre.memoriaalegre;
import control.Controlador;

import java.awt.event.*;
public class TelaConfigurações extends javax.swing.JFrame {

    public TelaConfigurações() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        nomeAlunoTextField = new javax.swing.JTextField();
        NomeAlunoLabel = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        DificuldadeComboBox = new javax.swing.JComboBox<>();
        TurmaComboBox = new javax.swing.JComboBox<>();
        EntrarFaseButton = new javax.swing.JButton();
        SairButton = new javax.swing.JButton();
        ConsultarButton = new javax.swing.JButton();
        ConfigLabel = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMaximumSize(new java.awt.Dimension(1280, 800));
        setMinimumSize(new java.awt.Dimension(1280, 800));
        setPreferredSize(new java.awt.Dimension(1280, 800));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        nomeAlunoTextField.setFont(new java.awt.Font("Trebuchet MS", 1, 20)); // NOI18N
        nomeAlunoTextField.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED, null, java.awt.Color.lightGray, null, null));
        nomeAlunoTextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nomeAlunoTextFieldActionPerformed(evt);
            }
        });
        getContentPane().add(nomeAlunoTextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 300, 380, 30));

        NomeAlunoLabel.setFont(new java.awt.Font("Trebuchet MS", 1, 24)); // NOI18N
        NomeAlunoLabel.setText("Nome Aluno ");
        getContentPane().add(NomeAlunoLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 250, 150, 30));

        jLabel5.setFont(new java.awt.Font("Trebuchet MS", 1, 24)); // NOI18N
        jLabel5.setText("Tempo");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 390, 80, 30));

        jLabel4.setFont(new java.awt.Font("Trebuchet MS", 1, 24)); // NOI18N
        jLabel4.setText("Tema ");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 520, 80, 30));

        DificuldadeComboBox.setFont(new java.awt.Font("Trebuchet MS", 1, 20)); // NOI18N
        DificuldadeComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "2 Minutos", "5 Minutos", "7 Minutos" }));
        DificuldadeComboBox.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED, null, java.awt.Color.lightGray, null, null));
        DificuldadeComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DificuldadeComboBoxActionPerformed(evt);
            }
        });
        getContentPane().add(DificuldadeComboBox, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 560, 380, 30));

        TurmaComboBox.setFont(new java.awt.Font("Trebuchet MS", 1, 20)); // NOI18N
        TurmaComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Frutas", "Animais", "Estações do ano" }));
        TurmaComboBox.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED, null, java.awt.Color.lightGray, null, null));
        TurmaComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TurmaComboBoxActionPerformed(evt);
            }
        });
        getContentPane().add(TurmaComboBox, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 430, 380, 30));

        EntrarFaseButton.setFont(new java.awt.Font("Trebuchet MS", 1, 18)); // NOI18N
        EntrarFaseButton.setText("Entrar");
        EntrarFaseButton.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED, null, java.awt.Color.lightGray, null, null));
        EntrarFaseButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EntrarFaseButtonActionPerformed(evt);
            }
        });
        getContentPane().add(EntrarFaseButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(850, 700, 100, 40));

        SairButton.setFont(new java.awt.Font("Trebuchet MS", 1, 18)); // NOI18N
        SairButton.setText("Voltar");
        SairButton.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED, null, java.awt.Color.lightGray, null, null));
        SairButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SairButtonActionPerformed(evt);
            }
        });
        getContentPane().add(SairButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 700, 100, 40));

        ConsultarButton.setFont(new java.awt.Font("Trebuchet MS", 1, 18)); // NOI18N
        ConsultarButton.setText("Consultar Pontuação ");
        ConsultarButton.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED, null, java.awt.Color.lightGray, null, null));
        ConsultarButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ConsultarButtonActionPerformed(evt);
            }
        });
        getContentPane().add(ConsultarButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 700, 190, 40));

        ConfigLabel.setBackground(new java.awt.Color(0, 0, 0));
        ConfigLabel.setFont(new java.awt.Font("Trebuchet MS", 0, 48)); // NOI18N
        ConfigLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        ConfigLabel.setText("Configurações");
        ConfigLabel.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        ConfigLabel.setDebugGraphicsOptions(javax.swing.DebugGraphics.NONE_OPTION);
        ConfigLabel.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        getContentPane().add(ConfigLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 150, 330, 60));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/TelaConfig_1_1.jpg"))); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, -140, 1920, 1080));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void SairButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SairButtonActionPerformed
    TelaInicial ti= new TelaInicial();
    ti.setVisible(true);
    }//GEN-LAST:event_SairButtonActionPerformed

    private void ConsultarButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ConsultarButtonActionPerformed
    this.dispose();
    TelaTabelaProfessor tltp= new TelaTabelaProfessor();
    tltp.setVisible(true);
    }//GEN-LAST:event_ConsultarButtonActionPerformed

    private void EntrarFaseButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EntrarFaseButtonActionPerformed
    this.dispose();
    String nome = nomeAlunoTextField.getText();
    Controlador.setNome(nome);
    TelaEntrarNomeAluno tena = new TelaEntrarNomeAluno();
    tena.setVisible(true);    
    }//GEN-LAST:event_EntrarFaseButtonActionPerformed

    private void nomeAlunoTextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nomeAlunoTextFieldActionPerformed

    }//GEN-LAST:event_nomeAlunoTextFieldActionPerformed

    private void DificuldadeComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DificuldadeComboBoxActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_DificuldadeComboBoxActionPerformed

    private void TurmaComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TurmaComboBoxActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TurmaComboBoxActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TelaConfigurações.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TelaConfigurações.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TelaConfigurações.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TelaConfigurações.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TelaConfigurações().setVisible(true);
            }
        });
    }
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel ConfigLabel;
    private javax.swing.JButton ConsultarButton;
    private javax.swing.JComboBox<String> DificuldadeComboBox;
    public javax.swing.JButton EntrarFaseButton;
    private javax.swing.JLabel NomeAlunoLabel;
    private javax.swing.JButton SairButton;
    private javax.swing.JComboBox<String> TurmaComboBox;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    public javax.swing.JTextField nomeAlunoTextField;
    // End of variables declaration//GEN-END:variables
}
