
package control;


public class Controlador {
    
    private static String nome;

    public static String getNome() {
        return nome;
    }

    public static void setNome(String novoNome) {
        nome = novoNome;
    }
}

