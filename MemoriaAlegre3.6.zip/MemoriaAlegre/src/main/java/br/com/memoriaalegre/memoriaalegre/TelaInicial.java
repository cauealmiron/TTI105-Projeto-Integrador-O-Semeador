
package br.com.memoriaalegre.memoriaalegre;

import java.awt.Dimension;
import java.awt.Toolkit;
import javax.swing.JFrame;

public class TelaInicial extends javax.swing.JFrame {

    public TelaInicial() {
        initComponents();
        //TelaInicial.setVisible(true);
        //Dimension screenSize = ToolKit.getDefaultToolkit().getScreenSize();
        //TelaInicial.setSize(screenSize.width;, screenSize.height);
        //TelaInicial.setExtendedState(JFrame.MAXIMIZED_BOTH);
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jPasswordField1 = new javax.swing.JPasswordField();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextPane1 = new javax.swing.JTextPane();
        momoriaAlegreTitle = new javax.swing.JLabel();
        mamoriaAlegreLogo = new javax.swing.JLabel();
        gardenBackground = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Memória Alegre - Tela Inicial");
        setBounds(new java.awt.Rectangle(0, 0, 1280, 800));
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        setEnabled(false);
        setMaximumSize(new java.awt.Dimension(1280, 800));
        setMinimumSize(new java.awt.Dimension(1280, 800));
        getContentPane().setLayout(null);

        jButton1.setFont(new java.awt.Font("Trebuchet MS", 0, 18)); // NOI18N
        jButton1.setText("SAIR");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1);
        jButton1.setBounds(470, 640, 110, 40);

        jButton2.setFont(new java.awt.Font("Trebuchet MS", 0, 18)); // NOI18N
        jButton2.setText("ENTRAR");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2);
        jButton2.setBounds(720, 640, 110, 40);

        jLabel1.setFont(new java.awt.Font("Trebuchet MS", 1, 24)); // NOI18N
        jLabel1.setText("Senha");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(610, 510, 70, 20);

        jLabel2.setFont(new java.awt.Font("Trebuchet MS", 1, 24)); // NOI18N
        jLabel2.setText("Nome Administrador");
        getContentPane().add(jLabel2);
        jLabel2.setBounds(530, 380, 240, 29);

        jPasswordField1.setFont(new java.awt.Font("Trebuchet MS", 0, 18)); // NOI18N
        jPasswordField1.setText("jPasswordField1");
        getContentPane().add(jPasswordField1);
        jPasswordField1.setBounds(460, 550, 380, 30);

        jTextPane1.setFont(new java.awt.Font("Trebuchet MS", 0, 18)); // NOI18N
        jTextPane1.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        jScrollPane1.setViewportView(jTextPane1);

        getContentPane().add(jScrollPane1);
        jScrollPane1.setBounds(460, 420, 380, 30);

        momoriaAlegreTitle.setFont(new java.awt.Font("Trebuchet MS", 1, 36)); // NOI18N
        momoriaAlegreTitle.setForeground(new java.awt.Color(255, 255, 255));
        momoriaAlegreTitle.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        momoriaAlegreTitle.setText("Bem-Vindo!");
        getContentPane().add(momoriaAlegreTitle);
        momoriaAlegreTitle.setBounds(380, 230, 540, 57);

        mamoriaAlegreLogo.setFont(new java.awt.Font("Trebuchet MS", 1, 48)); // NOI18N
        mamoriaAlegreLogo.setForeground(new java.awt.Color(255, 255, 255));
        mamoriaAlegreLogo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        mamoriaAlegreLogo.setText("Memória Alegre");
        getContentPane().add(mamoriaAlegreLogo);
        mamoriaAlegreLogo.setBounds(440, 170, 420, 57);

        gardenBackground.setFont(new java.awt.Font("Trebuchet MS", 1, 24)); // NOI18N
        gardenBackground.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/telaAdm_1.jpg"))); // NOI18N
        gardenBackground.addContainerListener(new java.awt.event.ContainerAdapter() {
            public void componentAdded(java.awt.event.ContainerEvent evt) {
                gardenBackgroundComponentAdded(evt);
            }
        });
        getContentPane().add(gardenBackground);
        gardenBackground.setBounds(0, -140, 1910, 1081);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        TelaConfigurações tc= new TelaConfigurações();
        tc.setVisible(true);
    }//GEN-LAST:event_jButton2ActionPerformed

    private void gardenBackgroundComponentAdded(java.awt.event.ContainerEvent evt) {//GEN-FIRST:event_gardenBackgroundComponentAdded

    }//GEN-LAST:event_gardenBackgroundComponentAdded

            
    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TelaInicial().setVisible(true);
            }
        });
    }
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel gardenBackground;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPasswordField jPasswordField1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextPane jTextPane1;
    private javax.swing.JLabel mamoriaAlegreLogo;
    private javax.swing.JLabel momoriaAlegreTitle;
    // End of variables declaration//GEN-END:variables
}
