package br.com.memoriaalegre.memoriaalegre;

public class Aluno {
    
    public String nomeAluno;
    public Integer pontuacao;

    public String getNomeAluno() {
        return nomeAluno;
    }

    public void setNomeAluno(String nomeAluno) {
        this.nomeAluno = nomeAluno;
    }

    public Integer getPontuacao() {
        return pontuacao;
    }

    public void setPontuacao(Integer pontuacao) {
        this.pontuacao = pontuacao;
    }
    
    
}
